import neuron
from neuron import h

h.load_file("init.hoc")
execfile("PlotResults.py")
quit()